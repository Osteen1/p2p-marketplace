import React from 'react';
import {
  Users,
  TrendingUp,
  DollarSign,
  BarChart2,
  ArrowUpRight,
  ArrowDownRight,
} from 'lucide-react';

const stats = [
  {
    name: 'Total Customers',
    value: '2,543',
    change: '+12.5%',
    trend: 'up',
    icon: Users,
  },
  {
    name: 'Active Leads',
    value: '185',
    change: '+8.2%',
    trend: 'up',
    icon: TrendingUp,
  },
  {
    name: 'Monthly Revenue',
    value: '$125,200',
    change: '-4.1%',
    trend: 'down',
    icon: DollarSign,
  },
  {
    name: 'Conversion Rate',
    value: '28.6%',
    change: '+2.3%',
    trend: 'up',
    icon: BarChart2,
  },
];

export default function Dashboard() {
  return (
    <div className="flex-1 p-8">
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500">Welcome back! Here's what's happening.</p>
      </div>

      <div className="mb-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <div
            key={stat.name}
            className="overflow-hidden rounded-lg bg-white p-6 shadow"
          >
            <div className="flex items-center">
              <div className="rounded-lg bg-blue-50 p-3">
                <stat.icon className="h-6 w-6 text-blue-600" />
              </div>
            </div>
            <div className="mt-4">
              <p className="text-sm font-medium text-gray-500">{stat.name}</p>
              <div className="mt-1 flex items-baseline justify-between">
                <p className="text-2xl font-semibold text-gray-900">
                  {stat.value}
                </p>
                <span
                  className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-sm ${
                    stat.trend === 'up'
                      ? 'bg-green-100 text-green-800'
                      : 'bg-red-100 text-red-800'
                  }`}
                >
                  {stat.trend === 'up' ? (
                    <ArrowUpRight className="mr-1 h-4 w-4" />
                  ) : (
                    <ArrowDownRight className="mr-1 h-4 w-4" />
                  )}
                  {stat.change}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-lg bg-white p-6 shadow">
          <h3 className="text-lg font-medium text-gray-900">Recent Activity</h3>
          <div className="mt-4 space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center space-x-4">
                <div className="h-8 w-8 rounded-full bg-gray-200"></div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">
                    New lead created
                  </p>
                  <p className="text-sm text-gray-500">2 hours ago</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-lg bg-white p-6 shadow">
          <h3 className="text-lg font-medium text-gray-900">
            Upcoming Meetings
          </h3>
          <div className="mt-4 space-y-4">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="flex items-center justify-between rounded-lg border border-gray-200 p-4"
              >
                <div>
                  <p className="font-medium text-gray-900">Client Review</p>
                  <p className="text-sm text-gray-500">Today at 2:00 PM</p>
                </div>
                <button className="rounded-lg bg-blue-50 px-3 py-1 text-sm font-medium text-blue-600">
                  Join
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}