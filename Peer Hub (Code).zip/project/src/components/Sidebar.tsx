import React from 'react';
import {
  LayoutDashboard,
  Users,
  BarChart3,
  Calendar,
  Settings,
  MessageSquare,
  ShoppingCart,
} from 'lucide-react';

const navigation = [
  { name: 'Dashboard', icon: LayoutDashboard, href: '/' },
  { name: 'Customers', icon: Users, href: '/customers' },
  { name: 'Orders', icon: ShoppingCart, href: '/orders' },
  { name: 'Analytics', icon: BarChart3, href: '/analytics' },
  { name: 'Calendar', icon: Calendar, href: '/calendar' },
  { name: 'Messages', icon: MessageSquare, href: '/messages' },
  { name: 'Settings', icon: Settings, href: '/settings' },
];

export default function Sidebar() {
  return (
    <div className="flex h-screen w-64 flex-col bg-gray-900 text-white">
      <div className="flex h-16 items-center px-6">
        <h1 className="text-xl font-bold">CRM Pro</h1>
      </div>
      <nav className="flex-1 space-y-1 px-2 py-4">
        {navigation.map((item) => (
          <a
            key={item.name}
            href={item.href}
            className="group flex items-center rounded-lg px-4 py-2 text-sm font-medium hover:bg-gray-800"
          >
            <item.icon className="mr-3 h-5 w-5" />
            {item.name}
          </a>
        ))}
      </nav>
    </div>
  );
}