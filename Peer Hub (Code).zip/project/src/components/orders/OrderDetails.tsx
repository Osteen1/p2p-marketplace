import React from 'react';
import { ArrowLeft, Clock, CreditCard, Package } from 'lucide-react';
import type { Order } from '../../types';

const orderDetails: Order = {
  id: 'ORD-001',
  customerId: '1',
  customerName: 'Acme Corporation',
  date: '2024-03-15',
  status: 'completed',
  total: 12500,
  paymentStatus: 'paid',
  items: [
    { id: '1', name: 'Enterprise License', quantity: 1, price: 12500 }
  ]
};

const statusSteps = [
  { icon: Package, label: 'Order Placed', date: '15 Mar, 2024 9:00 AM' },
  { icon: Clock, label: 'Processing', date: '15 Mar, 2024 9:30 AM' },
  { icon: CreditCard, label: 'Payment Confirmed', date: '15 Mar, 2024 10:00 AM' }
];

export default function OrderDetails() {
  return (
    <div className="flex-1 p-8">
      <div className="mb-8">
        <button className="mb-4 flex items-center text-gray-600 hover:text-gray-900">
          <ArrowLeft className="mr-2 h-5 w-5" />
          Back to Orders
        </button>
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Order {orderDetails.id}</h2>
            <p className="text-gray-500">{orderDetails.customerName}</p>
          </div>
          <div className="flex space-x-4">
            <button className="rounded-lg border border-gray-300 px-4 py-2 hover:bg-gray-50">
              Download Invoice
            </button>
          </div>
        </div>
      </div>

      <div className="mb-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
        <div className="rounded-lg bg-white p-6 shadow">
          <h3 className="mb-4 text-lg font-medium text-gray-900">Order Timeline</h3>
          <div className="space-y-6">
            {statusSteps.map((step, index) => (
              <div key={index} className="flex items-start">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-blue-100">
                  <step.icon className="h-5 w-5 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="font-medium text-gray-900">{step.label}</p>
                  <p className="text-sm text-gray-500">{step.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-lg bg-white p-6 shadow">
          <h3 className="mb-4 text-lg font-medium text-gray-900">Order Summary</h3>
          <div className="space-y-4">
            {orderDetails.items.map((item) => (
              <div key={item.id} className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-gray-900">{item.name}</p>
                  <p className="text-sm text-gray-500">Quantity: {item.quantity}</p>
                </div>
                <p className="font-medium text-gray-900">
                  ${item.price.toLocaleString()}
                </p>
              </div>
            ))}
            <div className="border-t pt-4">
              <div className="flex items-center justify-between font-medium text-gray-900">
                <p>Total Amount</p>
                <p>${orderDetails.total.toLocaleString()}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}