import React, { useState } from 'react';
import { AlertCircle, Upload, MessageSquare, Shield } from 'lucide-react';
import type { Dispute, DisputeEvidence } from '../../types';

interface DisputeResolutionProps {
  dispute: Dispute;
  onSubmitEvidence: (evidence: Partial<DisputeEvidence>) => void;
  onUpdateDispute: (disputeId: string, status: Dispute['status']) => void;
}

export default function DisputeResolution({
  dispute,
  onSubmitEvidence,
  onUpdateDispute,
}: DisputeResolutionProps) {
  const [evidenceDescription, setEvidenceDescription] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const handleSubmitEvidence = () => {
    if (!evidenceDescription) return;

    onSubmitEvidence({
      disputeId: dispute.id,
      type: 'payment_proof',
      description: evidenceDescription,
      submittedAt: new Date().toISOString(),
    });

    setEvidenceDescription('');
    setSelectedFile(null);
  };

  return (
    <div className="rounded-lg border bg-white p-6 shadow-sm">
      <div className="mb-6 flex items-center space-x-3">
        <AlertCircle className="h-6 w-6 text-red-500" />
        <h3 className="text-lg font-semibold">Dispute Resolution</h3>
      </div>

      <div className="mb-6 rounded-lg bg-red-50 p-4">
        <h4 className="mb-2 font-medium text-red-800">Dispute Reason:</h4>
        <p className="text-red-700">{dispute.reason}</p>
      </div>

      <div className="mb-6">
        <h4 className="mb-4 font-medium">Evidence Submitted</h4>
        <div className="space-y-4">
          {dispute.evidence.map((evidence) => (
            <div
              key={evidence.id}
              className="rounded-lg border border-gray-200 p-4"
            >
              <div className="mb-2 flex items-center justify-between">
                <span className="font-medium">{evidence.type}</span>
                <span className="text-sm text-gray-500">
                  {new Date(evidence.submittedAt).toLocaleDateString()}
                </span>
              </div>
              <p className="text-gray-600">{evidence.description}</p>
              {evidence.fileUrl && (
                <a
                  href={evidence.fileUrl}
                  className="mt-2 inline-flex items-center text-blue-600 hover:text-blue-700"
                >
                  <Upload className="mr-1 h-4 w-4" />
                  View Attachment
                </a>
              )}
            </div>
          ))}
        </div>
      </div>

      {dispute.status !== 'resolved' && (
        <div className="space-y-4">
          <div>
            <label className="mb-2 block text-sm font-medium text-gray-700">
              Add Evidence Description
            </label>
            <textarea
              value={evidenceDescription}
              onChange={(e) => setEvidenceDescription(e.target.value)}
              className="w-full rounded-lg border border-gray-300 p-2"
              rows={3}
              placeholder="Describe your evidence..."
            />
          </div>

          <div>
            <label className="mb-2 block text-sm font-medium text-gray-700">
              Upload Evidence (optional)
            </label>
            <input
              type="file"
              onChange={(e) => setSelectedFile(e.target.files?.[0] || null)}
              className="w-full rounded-lg border border-gray-300 p-2"
            />
          </div>

          <div className="flex space-x-3">
            <button
              onClick={handleSubmitEvidence}
              className="flex-1 rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
            >
              Submit Evidence
            </button>
            <button
              onClick={() => onUpdateDispute(dispute.id, 'under_review')}
              className="flex items-center rounded-lg border border-gray-300 px-4 py-2 hover:bg-gray-50"
            >
              <MessageSquare className="mr-2 h-4 w-4" />
              Request Mediator
            </button>
          </div>
        </div>
      )}

      {dispute.status === 'resolved' && dispute.resolution && (
        <div className="rounded-lg bg-green-50 p-4">
          <div className="mb-2 flex items-center space-x-2">
            <Shield className="h-5 w-5 text-green-600" />
            <h4 className="font-medium text-green-800">Resolution</h4>
          </div>
          <p className="text-green-700">{dispute.resolution}</p>
        </div>
      )}
    </div>
  );
}