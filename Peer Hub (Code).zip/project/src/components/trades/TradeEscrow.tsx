import React from 'react';
import { Shield, AlertTriangle, CheckCircle, Clock } from 'lucide-react';
import type { Trade, Escrow } from '../../types';

interface TradeEscrowProps {
  trade: Trade;
  escrow: Escrow;
  onFundEscrow: () => void;
  onReleaseEscrow: () => void;
  onRefundEscrow: () => void;
}

export default function TradeEscrow({
  trade,
  escrow,
  onFundEscrow,
  onReleaseEscrow,
  onRefundEscrow,
}: TradeEscrowProps) {
  const getStatusIcon = () => {
    switch (escrow.status) {
      case 'funded':
        return <Shield className="h-6 w-6 text-green-500" />;
      case 'released':
        return <CheckCircle className="h-6 w-6 text-blue-500" />;
      case 'refunded':
        return <AlertTriangle className="h-6 w-6 text-yellow-500" />;
      default:
        return <Clock className="h-6 w-6 text-gray-500" />;
    }
  };

  return (
    <div className="rounded-lg border bg-white p-6 shadow-sm">
      <div className="mb-6 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          {getStatusIcon()}
          <h3 className="text-lg font-semibold">Escrow Status</h3>
        </div>
        <span className="rounded-full bg-blue-100 px-3 py-1 text-sm font-medium text-blue-800">
          {escrow.status.charAt(0).toUpperCase() + escrow.status.slice(1)}
        </span>
      </div>

      <div className="mb-6 space-y-4">
        <div className="flex justify-between">
          <span className="text-gray-600">Amount in Escrow:</span>
          <span className="font-medium">
            {escrow.amount} {escrow.cryptocurrency}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-600">Created:</span>
          <span className="font-medium">
            {new Date(escrow.createdAt).toLocaleDateString()}
          </span>
        </div>
        {escrow.releasedAt && (
          <div className="flex justify-between">
            <span className="text-gray-600">Released:</span>
            <span className="font-medium">
              {new Date(escrow.releasedAt).toLocaleDateString()}
            </span>
          </div>
        )}
      </div>

      <div className="space-y-3">
        {escrow.status === 'funded' && (
          <>
            <button
              onClick={onReleaseEscrow}
              className="w-full rounded-lg bg-green-600 px-4 py-2 text-white hover:bg-green-700"
            >
              Release Funds
            </button>
            <button
              onClick={onRefundEscrow}
              className="w-full rounded-lg border border-red-600 px-4 py-2 text-red-600 hover:bg-red-50"
            >
              Request Refund
            </button>
          </>
        )}
        {!escrow.status && (
          <button
            onClick={onFundEscrow}
            className="w-full rounded-lg bg-blue-600 px-4 py-2 text-white hover:bg-blue-700"
          >
            Fund Escrow
          </button>
        )}
      </div>
    </div>
  );
}