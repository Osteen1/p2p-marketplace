export interface User {
  id: string;
  email: string;
  username: string;
  verified: boolean;
  kycStatus: 'none' | 'pending' | 'verified';
  twoFactorEnabled: boolean;
  createdAt: string;
  lastLogin: string;
}

export interface Trade {
  id: string;
  type: 'buy' | 'sell';
  cryptocurrency: string;
  amount: number;
  price: number;
  fiatCurrency: string;
  status: 'open' | 'in_escrow' | 'payment_sent' | 'completed' | 'disputed' | 'cancelled';
  escrowStatus: 'not_started' | 'funded' | 'released' | 'refunded';
  createdAt: string;
  seller: string;
  buyer: string;
  paymentTimeLimit: number; // in minutes
  disputeReason?: string;
  disputeResolution?: string;
  disputeStatus?: 'open' | 'under_review' | 'resolved';
  mediatorId?: string;
}

export interface Escrow {
  id: string;
  tradeId: string;
  sellerId: string;
  buyerId: string;
  amount: number;
  cryptocurrency: string;
  status: 'funded' | 'released' | 'refunded';
  createdAt: string;
  releasedAt?: string;
  refundedAt?: string;
}

export interface Dispute {
  id: string;
  tradeId: string;
  initiatorId: string;
  respondentId: string;
  reason: string;
  status: 'open' | 'under_review' | 'resolved';
  resolution?: string;
  mediatorId?: string;
  evidence: DisputeEvidence[];
  createdAt: string;
  resolvedAt?: string;
}

export interface DisputeEvidence {
  id: string;
  disputeId: string;
  userId: string;
  type: 'payment_proof' | 'chat_log' | 'document' | 'other';
  description: string;
  fileUrl?: string;
  submittedAt: string;
}

export interface Message {
  id: string;
  type: 'user' | 'bot' | 'system';
  content: string;
  timestamp: string;
}